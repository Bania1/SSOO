#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <errno.h>
#include <string.h>

int main()
{
    pid_t pid, flag;
    int status;

    pid=fork(); //Hijo B
    if (pid==-1)
    {
        printf("Error\n");
        exit(EXIT_FAILURE);
    }
    else if (pid==0)
    {
        printf("[HIJO B] ---> %ld y [PADRE A] ---> %ld\n", (long int)getpid(), (long int)getppid());
        exit(EXIT_SUCCESS);
    }
   
    pid=fork(); //Hijo c, padre a
    if (pid==-1)
    {
        printf("Error\n");
        exit(EXIT_FAILURE);
    }
    else if (pid==0)
    {
        printf("[HIJO C] ---> %ld y [PADRE A] ---> %ld\n", (long int)getpid(), (long int)getppid());
        
        pid=fork(); //Hijo d, padre c
        if (pid==-1)
        {
            printf("Error\n");
            exit(EXIT_FAILURE);
        }
        else if (pid==0)
        {
             printf("[HIJO D] ---> %ld y [PADRE C] ---> %ld\n", (long int)getpid(), (long int)getppid());
             exit(EXIT_SUCCESS);
        }
        
        pid=fork(); //Hijo e, padre c
        if (pid==-1)
        {
            printf("Error\n");
            exit(EXIT_FAILURE);
        }
        else if (pid==0)
        {
            printf("[HIJO E] ---> %ld y [PADRE C] ---> %ld\n", (long int)getpid(), (long int)getppid());

            pid=fork(); //Hijo f, padre e
            if (pid==-1)
            {
                printf("Error\n");
                exit(EXIT_FAILURE);
            }
            else if (pid==0)
            {
                printf("[HIJO F] ---> %ld y [PADRE E] ---> %ld\n", (long int)getpid(), (long int)getppid());
                exit(EXIT_SUCCESS);
            }
            else //Espera para e
            {
                while((flag=wait(&status))>0)
                {
                    if(WIFEXITED(status))
                    {
                        printf("hijo %ld finalizado con status %d\n",(long int)flag,WEXITSTATUS(status));
                    }
                    else if(WIFSIGNALED(status))
                    {
                        printf("hijo %ld finalizado tras recibir una senal con status %d\n",(long int)flag,WTERMSIG(status));
                    }
                    else if(WIFSTOPPED(status))
                    {
                        printf("hijo %ld parado con status %d\n",(long int)flag,WSTOPSIG(status));
                    }
                    else if(WIFCONTINUED(status))
                    {
                        printf("hijo %ld reanudado\n",(long int)flag);
                    }

                }
                if(flag==(pid_t)-1 && errno==ECHILD)
                { 
                    printf("Valor del errno= %d, definido como %s\n",errno,strerror(errno));
                }
                else
                {
                    printf("Error en la invocacion de wait o la llamada ha sido interrumpida por una señal\n");
                    exit(EXIT_FAILURE);
                } 

                exit(EXIT_SUCCESS);
            }
            
            
            exit(EXIT_SUCCESS);
        }
        else //Espera de d y e
        {
            while((flag=wait(&status))>0)
            {
                if(WIFEXITED(status))
                {
                    printf("hijo %ld finalizado con status %d\n",(long int)flag,WEXITSTATUS(status));
                }
                else if(WIFSIGNALED(status))
                {
                    printf("hijo %ld finalizado tras recibir una senal con status %d\n",(long int)flag,WTERMSIG(status));
                }
                else if(WIFSTOPPED(status))
                {
                    printf("hijo %ld parado con status %d\n",(long int)flag,WSTOPSIG(status));
                }
                else if(WIFCONTINUED(status))
                {
                    printf("hijo %ld reanudado\n",(long int)flag);
                }

            }
            if(flag==(pid_t)-1 && errno==ECHILD)
            { 
                printf("Valor del errno= %d, definido como %s\n",errno,strerror(errno));
            }
            else
            {
                printf("Error en la invocacion de wait o la llamada ha sido interrumpida por una señal\n");
                exit(EXIT_FAILURE);
            } 

            exit(EXIT_SUCCESS);
         
        }
          
        exit(EXIT_SUCCESS);
    }
    else //Espera de a
    {
            printf("[PADRE] ---> %ld\n", (long int)getpid());
            while((flag=wait(&status))>0)
            {
                if(WIFEXITED(status))
                {
                    printf("hijo %ld finalizado con status %d\n",(long int)flag,WEXITSTATUS(status));
                }
                else if(WIFSIGNALED(status))
                {
                    printf("hijo %ld finalizado tras recibir una senal con status %d\n",(long int)flag,WTERMSIG(status));
                }
                else if(WIFSTOPPED(status))
                {
                    printf("hijo %ld parado con status %d\n",(long int)flag,WSTOPSIG(status));
                }
                else if(WIFCONTINUED(status))
                {
                    printf("hijo %ld reanudado\n",(long int)flag);
                }

            }
            if(flag==(pid_t)-1 && errno==ECHILD)
            { 
                printf("Valor del errno= %d, definido como %s\n",errno,strerror(errno));
            }
            else
            {
                printf("Error en la invocacion de wait o la llamada ha sido interrumpida por una señal\n");
                exit(EXIT_FAILURE);
            } 

            exit(EXIT_SUCCESS);
    }
    
}